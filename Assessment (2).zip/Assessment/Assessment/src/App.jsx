import './App.css'
import Home from './Pages/Home'
import { BrowserRouter as Router, Route, Routes } from 'react-router-dom';
import StepperForm from './Pages/stepperform';
function App() {


  return (
    <>
     <Router>
      <div>
    
        <Routes>
          <Route path="/" element={<Home />} />
      <Route path='stepper-form' element={<StepperForm/>} />
        </Routes>
      </div>
    </Router>
     
    </>
  )
}

export default App
