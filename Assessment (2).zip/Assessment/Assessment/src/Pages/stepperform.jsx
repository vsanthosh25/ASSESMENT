import React, { useState } from 'react';
import './StepperForm.css'; // Import your custom CSS


const formConfig = {
  steps: [
    {
      label: 'Personal Information',
      fields: [
        { name: 'firstName', label: 'First Name', type: 'text', required: true },
        { name: 'lastName', label: 'Last Name', type: 'text', required: true },
        { name: 'email', label: 'Email', type: 'email', required: true },
      ],
    },
    {
      label: 'Job Details',
      fields: [
        { name: 'jobTitle', label: 'Job Title', type: 'text', required: true },
        { name: 'department', label: 'Department', type: 'text', required: true },
        { name: 'joiningDate', label: 'Joining Date', type: 'date', required: true },
      ],
    },
    {
      label: 'Contact Information',
      fields: [
        { name: 'phone', label: 'Phone Number', type: 'tel', required: true },
        { name: 'address', label: 'Address', type: 'text', required: true },
        { name: 'city', label: 'City', type: 'text', required: true },
      ],
    },
    {
      label: 'Bank Details',
      fields: [
        { name: 'bankName', label: 'Bank Name', type: 'text', required: true },
        { name: 'accountNumber', label: 'Account Number', type: 'text', required: true },
        { name: 'ifscCode', label: 'IFSC Code', type: 'text', required: true },
      ],
    },
  ],
};

const StepperForm = () => {
  const [activeStep, setActiveStep] = useState(0);
  const [formData, setFormData] = useState({});

  const handleNext = () => {
    if (activeStep < formConfig.steps.length - 1) {
      setActiveStep(activeStep + 1);
    }
  };

  const handleBack = () => {
    if (activeStep > 0) {
      setActiveStep(activeStep - 1);
    }
  };

  const handleChange = (e) => {
    const { name, value } = e.target;
    setFormData((prevData) => ({
      ...prevData,
      [name]: value,
    }));
  };

  const handleSubmit = () => {
    console.log('Form Data:', formData);
    // Add your form submission logic here
  };

  return (
    <div className="stepper-form">
      <div className="stepper">
        {formConfig.steps.map((step, index) => (
          <div key={index} className={`step ${activeStep === index ? 'active' : ''}`}>
            {step.label}
          </div>
        ))}
      </div>
      <div className="form-content">
        {formConfig.steps[activeStep].fields.map((field) => (
          <div key={field.name} className="form-field">
            <label htmlFor={field.name}>{field.label}</label>
            <input
              id={field.name}
              name={field.name}
              type={field.type}
              required={field.required}
              onChange={handleChange}
            />
          </div>
        ))}
      </div>
      <div className="form-navigation">
        <button onClick={handleBack} disabled={activeStep === 0}>
          Back
        </button>
        {activeStep === formConfig.steps.length - 1 ? (
          <button onClick={handleSubmit}>Submit</button>
        ) : (
          <button onClick={handleNext}>Next</button>
        )}
      </div>
    </div>
  );
};

export default StepperForm;
