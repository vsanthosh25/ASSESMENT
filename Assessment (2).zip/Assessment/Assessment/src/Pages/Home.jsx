import React from 'react'
import CustomInput from '../Components/CustomInput';
import CustomSelect from '../Components/CustomSelect';
import DatePickerInput from '../Components/DatePickerInput';
import { useFormik } from 'formik';
import { validationSchema } from '../Validation';
import "./Home.css"
import StepperForm from './stepperform';
import { Link } from 'react-router-dom';
const Home = () => {

    

    const formik = useFormik({
        initialValues: {
          name: '',
          email: '',
          category: '',
          date: '',
        },
        validationSchema,
        onSubmit: (values) => {
          console.log('Form values:', values);
          alert('Form submitted successfully!');
        },
      });
    

  return (
<>

<div>
<Link to="stepper-form">
  <button
    style={{
      color: "black",
      backgroundColor: "#4CAF50",
      padding: "10px 20px",
      border: "none",
      borderRadius: "5px",
      cursor: "pointer",
      fontSize: "16px",
    }}
  >
    Stepperform
  </button>
</Link>
</div>
<div>
    <h1>GOZEN Assessment</h1>
</div>

    <div className='home-container'>
      <form onSubmit={formik.handleSubmit}>
        {/* Custom Input for Name */}
        <CustomInput
          label="Name"
          name="name"
          type="text"
          onChange={formik.handleChange}
          onBlur={formik.handleBlur}
          value={formik.values.name}
        />
        {formik.touched.name && formik.errors.name ? (
          <div className="error">{formik.errors.name}</div>
        ) : null}

        {/* Custom Input for Email */}
        <CustomInput
          label="Phone Number"
          name="number"
          type="number"
          onChange={formik.handleChange}
          onBlur={formik.handleBlur}
          value={formik.values.number}
        />
        {formik.touched.number && formik.errors.number ? (
          <div className="error">{formik.errors.number}</div>
        ) : null}

        {/* Custom Select for Category */}
        <CustomSelect
          label="Category"
          name="category"
          options={[
            { value: 'developer', label: 'Developer' },
            { value: 'designer', label: 'Designer' },
            { value: 'manager', label: 'Manager' },
          ]}
          onChange={formik.handleChange}
          onBlur={formik.handleBlur}
          value={formik.values.category}
        />
        {formik.touched.category && formik.errors.category ? (
          <div className="error">{formik.errors.category}</div>
        ) : null}

        {/* Date Picker for Date */}
        <DatePickerInput
          label="Date"
          name="date"
          onChange={formik.handleChange}
          onBlur={formik.handleBlur}
          value={formik.values.date}
        />
        {formik.touched.date && formik.errors.date ? (
          <div className="error">{formik.errors.date}</div>
        ) : null}

  {/* Custom Input for Email */}
  <CustomInput
          label="Password"
          name="password"
          type="password"
          onChange={formik.handleChange}
          onBlur={formik.handleBlur}
          value={formik.values.password}
        />
        {formik.touched.password && formik.errors.password ? (
          <div className="error">{formik.errors.password}</div>
        ) : null}
        <button type="submit" className="btn btn-primary">
          Submit
        </button>
      </form>
  
    </div>
</>



  )
}

export default Home;