import React from 'react'

const CustomSelect = ({ label, options, ...props }) => (
    <div className="form-group">
      <label>{label}</label>
      <select className="form-control" {...props}>
        <option value="">Select an option</option>
        {options.map((option) => (
          <option key={option.value} value={option.value}>
            {option.label}
          </option>
        ))}
      </select>
    </div>
  );

export default CustomSelect;