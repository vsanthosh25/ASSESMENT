// src/components/DatePickerInput.jsx
import React from 'react';

const DatePickerInput = ({ label, ...props }) => (
  <div className="form-group">
    <label>{label}</label>
    <input className="form-control" type="date" {...props} />
  </div>
);

export default DatePickerInput;
