// src/components/CustomInput.jsx
import React from 'react';

const CustomInput = ({ label, ...props }) => (
  <div className="form-group">
    <label>{label}</label>
    <input className="form-control" {...props} />
  </div>
);

export default CustomInput;
