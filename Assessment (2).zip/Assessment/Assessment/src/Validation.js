
import * as Yup from 'yup';

export const validationSchema = Yup.object({
    name: Yup.string().required('Name is required'),
    number: Yup.string().required('Phone Number is required'),
    category: Yup.string().required('Category is required'),
    date: Yup.date().required('Date is required'),
  });
